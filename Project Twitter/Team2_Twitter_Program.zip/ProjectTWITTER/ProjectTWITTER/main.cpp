//Jason Do's main did not compile and not legable so remade in new main Jason made the output look nice
//Willis Wang remade main but did not make it look nice
//Patricia did file input and helped make the program more user friendly
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE_
#include <iostream>
#include <limits>
#include <string>
#include <iomanip>
#include <fstream>
#include "Server.h"
#include "User.h"

using namespace std;
void displaylogo();

int main(){
	Server helper;
	string filename;
	Queue<string> userQueue;
	Queue<string> passQueue;
	filename = "Users/user.txt";
	ifstream infile;
	infile.open(filename.c_str());

	//Reads keys of the hashtable from input file and puts them in a queue
	if (infile)
	{
		string key;
		while (getline(infile, key))
		{
			string pass;
			getline(infile, pass);
			User* temp = new User(key, pass);
			helper.addUser(temp);
			userQueue.add(key);
			passQueue.add(pass);
		}
	}
	else
		cout << " File that holds keys of the hash table couldn't be open...\n";
	infile.close();
	while (!userQueue.isEmpty())
	{

		string userName = userQueue.pop();
		int numFollower;

		filename = "Users/"+userName + ".txt";
		infile.open(filename.c_str());

		if (infile)
		{
			User* user = helper.getUser(userName, passQueue.pop());
			//number following
			string lines;
			getline(infile, lines);
			numFollower = atoi(lines.c_str());
			for (int i = 0; i < numFollower; i++)
			{
				getline(infile, lines);
				helper.addFollower(user, lines);
			}
			while (getline(infile, lines))
			{
				string post;
				int date = 0, hr = 0, mn = 0, sec = 0, year = 0, holdWdat = 0, holdMonth = 0;
				char day[3], month[3], dtm[200];
				infile.getline(dtm, 200, '\n');
				sscanf(dtm, "%s %s %d %d:%d:%d %d", day, month, &date, &hr, &mn, &sec, &year);

				string Month[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
				for (int i = 0; i < 12; i++)
				{
					if (Month[i] == month)
					{
						holdMonth = i;
						break;
					}
				}
				string Wday[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
				for (int i = 0; i < 7; i++)
				{
					if (Wday[i] == day)
					{
						holdWdat = i;
						break;
					}
				}
				time_t rawtime;
				struct tm *timeinfo;
				time(&rawtime);
				timeinfo = localtime(&rawtime);

				timeinfo->tm_wday = holdWdat;
				timeinfo->tm_mon = holdMonth;
				timeinfo->tm_mday = date;
				timeinfo->tm_hour = hr;
				timeinfo->tm_min = mn;
				timeinfo->tm_sec = sec;
				timeinfo->tm_year = year - 1900;
				timeinfo->tm_isdst = 0;
				time_t timeTemp = mktime(timeinfo);
				getline(infile, post);
				Tweet* temp = new Tweet(lines, post, timeTemp);
				helper.add(user, temp);
			}
		}
		infile.close();
	}
	

	displaylogo();
	
	//choice for first menu
	int choice;
	do{

		//main menu
		cout << endl << " Welcome to Twitter!  Please enter a number to indicate what you wish to do." << endl<<endl;
		cout << "\t1. Login" << endl;
		cout << "\t2. Register" << endl;
		cout << "\t3. Show Users in BST" << endl;
		cout << "\t4. Show Efficiency" << endl;
		cout << "\t5. Write Keys to file" << endl;
		cout << "\t6. Exit" << endl<<endl;
		cout << " Option #: ";
		cin >> choice;

		while (cin.fail() || choice<1 || choice>6) //If the input is not an integer ask the user to try again 
		{
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cout << "\n I'm sorry, that's an invalid input!. Please try again..." << endl << " Option #: ";
			cin >> choice;
		}

		cin.clear();
		cin.ignore(numeric_limits <streamsize> ::max(), '\n');

		if (choice == 1){
			cout <<endl<< string(94, '-') << endl << endl;
			cout << "\t\t\t      L O G   I N   T O   T W I T T E R"<<endl<<endl;
			string username, pass;
			cout << " Please enter your username: ";
			getline(cin, username);
			cout << "\n Please enter your password: ";
			getline(cin, pass);
			//gets the user object returns NULL if not vaild pass or user
			User* user = helper.getUser(username, pass);
			//when not valid user or password
			if (user != NULL){
				cout << endl<<endl;
				system("pause");
				system("CLS");
				displaylogo();
				int userChoice;
				cout << endl << " Welcome " << user->getUsername() << "!" << endl << endl;
				do{
					//user's menu
					cout << endl << " What would you like to do?  Please enter a valid choice." << endl<<endl;
					cout << "\t1. Add Tweet" << endl;
					cout << "\t2. View Newsfeed" << endl;
					cout << "\t3. View My Profile" << endl;
					cout << "\t4. Follow a user" << endl;
					cout << "\t5. Delete My account" << endl;
					cout << "\t6. Logout" << endl<<endl;
					cout << " Option #: ";
					cin >> userChoice;
					
					while (cin.fail()||userChoice<1||userChoice>6) //If the input is not an integer ask the user to try again 
					{
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout << "\n I'm sorry, that's an invalid input!. Please try again..." << endl<<" Option #: ";
						cin >> userChoice;
					}
					
					cin.clear();
					cin.ignore(numeric_limits<streamsize>::max(), '\n');
					
					//Adds a tweet
					if (userChoice == 1){
						string msg;
						cout << endl << string(94, '-') << endl << endl;
						cout << " What's on your mind?:" << endl<<endl;
						cout << " Tweet Msg: ";
						getline(cin, msg);
						helper.add(user, msg);
						cout << endl << string(94, '=') << endl << endl;
					}
					else if (userChoice == 2){//displays the users newsfeed
						cout << endl << string(94, '-') << endl << endl;
						cout << "\t\t\t\t   M Y   N E W S F E E D" << endl<<endl;
						user->displayNewsFeed();
						cout << endl << string(94, '=') << endl << endl;
					}
					else if (userChoice == 3){//views their profile
						cout << endl << string(94, '-') << endl<<endl;
						cout << " Redirecting to your Profile\n\n ";
						system("pause");
						system("CLS");
						displaylogo();
						int pChoice;
						do{
							//Menu for the users profile
							cout << " What would you like to do?  Please enter a valid choice." << endl<<endl;
							cout << "\t1. View My Tweets" << endl;
							cout << "\t2. Delete a Tweet" << endl;
							cout << "\t3. View My Followers" << endl;
							cout << "\t4. View who I am Following" << endl;
							cout << "\t5. Unfollow" << endl;
							cout << "\t6. Back" << endl<<endl;
							cout << " Option #: ";
							cin >> pChoice;

							while (cin.fail() || pChoice<1 || pChoice>6) //If the input is not an integer ask the user to try again 
							{
								cin.clear();
								cin.ignore(numeric_limits<streamsize>::max(), '\n');
								cout << "\n I'm sorry, that's an invalid input!. Please try again..." << endl << " Option #: ";
								cin >> pChoice;
							}

							//views their tweets
							if (pChoice == 1){
								cout << endl << string(94, '-') << endl << endl;
								cout << "\t\t\t\t\tM Y   T W E E T S\n\n";
								user->displayMyTweets();
								cout << endl << string(94, '=') << endl << endl;

							}
							else if (pChoice == 2){//deletes a tweet
								cout << endl << string(94, '-') << endl << endl;
								cout << "\t\t\t\t  D E L E T E   A   T W E E T" << endl << endl;
								//displays all their tweets
								Queue<MyTweet> myTweetStream;
								user->toQueueMyTweet(myTweetStream);
								int i = 0;
								int option;
								if (!myTweetStream.isEmpty()){
									while (!myTweetStream.isEmpty()){ //somehow the queue is not empty even when it should be
										i++;
										cout << i << ". " << myTweetStream.pop() << endl;
									}
									//user selects a number to delete
									cout << "\n Please select the Tweet you would like to delete by entering its number." << endl<<" Tweet #: ";
									cin >> option;

									while (cin.fail() || option<1 || option>i) //If the input is not an integer ask the user to try again 
									{
										cin.clear();
										cin.ignore(numeric_limits<streamsize>::max(), '\n');
										cout << "\n I'm sorry, that's an invalid input!. Please try again..." << endl << " Tweet #: ";
										cin >> option;
									}
									cin.clear();
									cin.ignore(numeric_limits <streamsize> ::max(), '\n');
									if (option <= i && option >= 1){
										MyTweet temp = user->getMyTweet(option - 1);
										helper.remove(user, temp);
										cout << " \n\n The Tweet has been successfully deleted" << endl;
									}
								}
								else{//when the user has no tweets
									cout << " There are currently no tweets to delete." << endl;
								}
								cout << endl << string(94, '=') << endl << endl;
							}
							else if (pChoice == 3){//outputs the users followers
								cout << endl << string(94, '-') << endl << endl;
								cout << "\t\t\t\t   M Y    F O L L O W E R S" << endl << endl;
								cout << endl << " Number of Followers: " << user->getFollowers() << endl<<endl;
								user->displayFollowers();
								cout << endl << string(94, '=') << endl << endl;
							}
							else if (pChoice == 4){//outputs who the user follows
								cout << endl << string(94, '-') << endl << endl;
								cout << "\t\t\t\t      F O L L O W I N G" << endl << endl;
								cout << endl << " Number of People I Follow: " << user->getFollowing() << endl<<endl;
								user->displayFollowing();
								cout << endl << string(94, '=') << endl << endl;
							}
							else if (pChoice == 5){//unfollows a user
								string temp;
								cout << endl << string(94, '-') << endl << endl;
								cout << "\t\t\t\t    U N F O L L O W" << endl << endl;
								cout << " Please enter the username of the person you would like to Unfollow." << endl<<" ";
								cin.clear();
								cin.ignore(numeric_limits<streamsize>::max(), '\n');
								getline(cin, temp);
								//checks to see if the user is following the person first
								if (user->amFollowing(temp)){
									helper.unFollow(user, temp);
									cout << "\n\n You have now unfollowed " << temp << "  :(" << endl;
								}
								else{//when a non vaild person is unfollowed
									cout <<"\n\n "<< temp << " is not valid choice/you are not following " << temp << "!" << endl;
								}
								cout << endl << string(94, '=') << endl << endl;
							}
							else{
								cout << endl << string(94, '=') << endl << endl;

							}
							
						} while (pChoice != 6);
						system("pause");
						system("CLS");
						displaylogo();
					}
					else if (userChoice == 4){//following a user
						cout << endl << string(94, '-') << endl << endl;
						cout << " Who is in Twitter right now?... " << endl << endl;
						helper.displayUsers();

						string temp;
						cout << endl <<endl<< " Please enter the username of the person you would like to follow." << endl<<" ";
						getline(cin, temp);
						//checks if it is a valid user to follow
						if (!helper.checkKey(temp) && !user->amFollowing(temp) && temp != user->getUsername()){
							helper.follow(user, temp);
							cout << "\n You are now following " << temp << "!" << endl;
						}
						else{
							cout <<"\n " <<temp << " is not a valid user or already following!" << endl;
						}
						cout << endl << string(94, '=') << endl << endl;
					}

					else if (userChoice == 5){//Delete account
						cout << endl << string(94, '-') << endl << endl;
						cout << "\t\t\t\tD E L E T E   M Y   A C C O U N T" << endl << endl;
						int sure;
						cout << " Is this goodbye?" << endl << " Are you sure you don't want to reconsider?\n\n";
						cout << " Enter 1 for confirmation: ";
						cin >> sure;
						
						while (cin.fail()) //If the input is not an integer ask the user to try again 
						{
							cin.clear();
							cin.ignore(numeric_limits<streamsize>::max(), '\n');
							cout << "\n I'm sorry, that's an invalid input!. Please try again..." << endl << " Enter 1 for confirmation: ";
							cin >> sure;
						}
						cin.clear();
						cin.ignore(numeric_limits <streamsize> ::max(), '\n');

						if (sure == 1){
							string fileNam = "Users/" + user->getUsername() + ".txt";
							helper.removeUser(user);
							user = NULL;
							remove(fileNam.c_str());
							cout << "\n Your account has been deleted :(" << endl;
						}
						else{
							userChoice = 0;
						}
						cout << endl << string(94, '=') << endl << endl;
					}
					else{//exit the user logout 
						cout << endl << string(94, '=') << endl << endl;
						cout << " Goodbye! " << user->getUsername() << endl<<endl;
						user = NULL;
					}
					
				} while (userChoice != 5 && userChoice != 6);
				system("pause");
				system("CLS");
				displaylogo();
			}
			else{//when user == NULL
				cout << "\n Invalid Username and/or Password!" << endl<<endl;
				cout << endl << string(94, '=') << endl << endl;
			}
		}
		else if (choice == 2){//for creating a new user
			cout << endl << string(94, '-') << endl<<endl;
			cout << "\t\t\t     J O I N   T W I T T E R   T O D A Y" << endl;
			string username, pass, test;
			//checking if good inputs
			bool isGood = false;
			do{
				cout  <<endl<< " Enter your desired username. Or type 'exit' to exit this process: ";
				getline(cin, username);
				test = username;
				//makes everything lowercase
				for (int i = 0; i < test.length(); i++)
				{
					test[i] = tolower(test[i]);
				}
				isGood = helper.checkKey(username);
				//checks the validity of the username
				if ((!isGood || test == "user") && test != "exit"){
					cout << " This username is already taken... Please try again" << endl;
				}
			} while ((test != "exit") && (!isGood || test == "user"));//keeps going while the not exit or invalid user name
			if (test != "exit"){
				cout << "\n Please enter your desired password: ";
				getline(cin, pass);
				//creates the new user
				User* user = new User(username, pass);
				//adds user to the server
				helper.addUser(user);
				cout << "\n\n\t\t\t  Your account has successfully been created!\n" ;
				cout << endl << string(94, '=') << endl << endl;
			}
		}
		else if (choice == 3){
			//shows bst style keys
			cout << endl << string(94, '-') << endl << endl;
			cout << "\t\t\t\tUsers in the Binary Search Tree\n\n";
			helper.showIndentedKey();
			cout << endl << string(94, '=') << endl << endl;
		}
		else if (choice == 4){//gets the efficiency of the hash table
			cout << endl << string(94, '-') << endl << endl;
			cout << "\t\t\t\t     Efficiency of a Key\n\n";
			helper.getEff();
			cout << endl << string(94, '=') << endl << endl;
		}
		else if (choice == 5){
			cout << endl << string(94, '-') << endl << endl;
			helper.writeKey();
			cout << " These keys were written to the file Keys.txt" << endl<<endl;
			helper.displayUsers();
			cout << endl << string(94, '=') << endl << endl;
		}
		else {//exit
			cout << endl << string(94, '=') << endl << endl;
			cout << " Goodbye!" << endl << endl;
		}
		
	} while (choice != 6);//exit
	system("pause");
	return 0;
}

void displaylogo()
{
	cout << string(94, '=') << endl << endl;
	cout << " /$$$$$$$$            /$$   /$$     /$$                                              .--.     " << endl;
	cout << "|__  $$__/           |__/  | $$    | $$                                            .'  o \\__ " << endl;
	cout << "   | $$ /$$  /$$  /$$ /$$ /$$$$$$ /$$$$$$    /$$$$$$   /$$$$$$                 _.-'    , (  ` " << endl;
	cout << "   | $$| $$ | $$ | $$| $$|_  $$_/|_  $$_/   /$$__  $$ /$$__  $$           _.-''      ,;; |    " << endl;
	cout << "   | $$| $$ | $$ | $$| $$  | $$    | $$    | $$$$$$$$| $$  \\__/      _.-=' _,'      ,,;;;'    " << endl;
	cout << "   | $$| $$ | $$ | $$| $$  | $$ /$$| $$ /$$| $$_____/| $$         .-'`_.- '``-..,,;;;;:'      " << endl;
	cout << "   | $$|  $$$$$/$$$$/| $$  |  $$$$/|  $$$$/|  $$$$$$$| $$         `''`           `\\`\\       " << endl;
	cout << "   |__/ \\_____/\\___/ |__/   \\___/   \\___/   \\_______/|__/                         /^\\\\\\    " << endl << endl;
	cout << string(94, '=') << endl << endl;

}


